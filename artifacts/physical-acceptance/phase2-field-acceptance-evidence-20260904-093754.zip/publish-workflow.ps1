[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string]$TemplatePath,
    [Parameter(Mandatory = $true)] [string]$OutputDirectory,
    [string]$MesBaseUrl = 'http://127.0.0.1:5145',
    [string]$Actor = 'admin'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Add-Type -AssemblyName System.Net.Http

function Copy-Map {
    param([AllowNull()][object]$Value)
    $result = [ordered]@{}
    if ($null -ne $Value) {
        foreach ($property in $Value.PSObject.Properties) {
            $result[$property.Name] = $property.Value
        }
    }
    return $result
}

function Save-Json {
    param([string]$Path, [object]$Value)
    [IO.File]::WriteAllText(
        $Path,
        ($Value | ConvertTo-Json -Depth 60),
        [Text.UTF8Encoding]::new($false))
}

function Invoke-Utf8JsonPost {
    param(
        [Parameter(Mandatory = $true)] [string]$Uri,
        [AllowNull()] [string]$Body
    )

    $client = [System.Net.Http.HttpClient]::new()
    $request = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Post, $Uri)
    try {
        if ($null -ne $Body) {
            $request.Content = [System.Net.Http.StringContent]::new(
                $Body,
                [Text.Encoding]::UTF8,
                'application/json')
        }
        $response = $client.SendAsync($request).GetAwaiter().GetResult()
        $text = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        if (-not $response.IsSuccessStatusCode) {
            throw "HTTP $([int]$response.StatusCode): $text"
        }
        return [pscustomobject]@{
            StatusCode = [int]$response.StatusCode
            Content = $text
        }
    }
    finally {
        $request.Dispose()
        $client.Dispose()
    }
}

if (-not (Test-Path -LiteralPath $TemplatePath -PathType Leaf)) {
    throw "Template file not found: $TemplatePath"
}
if (-not (Test-Path -LiteralPath $OutputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}

$document = Get-Content -Raw -Encoding UTF8 $TemplatePath | ConvertFrom-Json
$source = @($document.Workflows) |
    Where-Object { @($_.Nodes).Count -eq 9 -and @($_.Edges).Count -eq 8 } |
    Select-Object -First 1
if ($null -eq $source) { throw 'The approved material workflow template was not found.' }

$workflowId = [Guid]::NewGuid()
$nodeMap = @{}
foreach ($node in @($source.Nodes)) {
    $nodeMap[[string]$node.Id] = [Guid]::NewGuid()
}
$edgeMap = @{}
foreach ($edge in @($source.Edges)) {
    $edgeMap[[string]$edge.Id] = [Guid]::NewGuid()
}
$typeMap = @{
    'core.start' = 0
    'agv.move' = 1
    'robot.execute-program' = 8
    'core.end' = 5
}
$layouts = @{}
foreach ($layout in @($source.Layouts)) {
    $layouts[[string]$layout.NodeId] = $layout
}

$edges = @()
foreach ($edge in @($source.Edges)) {
    $edges += [ordered]@{
        id = $edgeMap[[string]$edge.Id]
        sourceNodeId = $nodeMap[[string]$edge.SourceNodeId]
        sourcePort = [string]$edge.SourcePort
        targetNodeId = $nodeMap[[string]$edge.TargetNodeId]
        targetPort = [string]$edge.TargetPort
        kind = [int]$edge.Kind
        condition = $edge.Condition
        conditionExpression = $edge.ConditionExpression
        priority = [int]$edge.Priority
        metadata = Copy-Map $edge.Metadata
    }
}

$nodes = @()
$order = 1
foreach ($node in @($source.Nodes)) {
    $typeId = [string]$node.NodeTypeId
    if (-not $typeMap.ContainsKey($typeId)) {
        throw "Unsupported template node type '$typeId'."
    }

    $configuration = [ordered]@{}
    foreach ($property in $node.Configuration.PSObject.Properties) {
        $configuration[$property.Name] =
            if ($null -eq $property.Value) { $null } else { [string]$property.Value }
    }
    $targetStation = $null
    $targetProperty = $node.Configuration.PSObject.Properties['$targetStation']
    if ($null -ne $targetProperty) { $targetStation = [string]$targetProperty.Value }

    $layout = $layouts[[string]$node.Id]
    $nextNodeIds = @(
        @($source.Edges |
            Where-Object {
                [string]$_.SourceNodeId -eq [string]$node.Id -and
                [string]$_.SourcePort -eq 'success' -and
                [int]$_.Kind -eq 0
            } |
            Sort-Object Priority |
            ForEach-Object { $nodeMap[[string]$_.TargetNodeId] })
    )

    $ports = @()
    foreach ($port in @($node.Ports)) {
        $ports += [ordered]@{
            key = [string]$port.Key
            displayName = [string]$port.DisplayName
            direction = [int]$port.Direction
            dataType = [string]$port.DataType
            cardinality = [int]$port.Cardinality
            edgeKind = if ($null -eq $port.EdgeKind) { $null } else { [int]$port.EdgeKind }
        }
    }

    $nodes += [ordered]@{
        id = $nodeMap[[string]$node.Id]
        type = [int]$typeMap[$typeId]
        nodeTypeId = $typeId
        schemaVersion = [string]$node.SchemaVersion
        name = [string]$node.Name
        description = [string]$node.Description
        targetStation = $targetStation
        x = if ($null -eq $layout) { 0 } else { [double]$layout.X }
        y = if ($null -eq $layout) { 0 } else { [double]$layout.Y }
        order = $order
        parameters = @()
        nextNodeIds = $nextNodeIds
        ports = $ports
        configuration = $configuration
    }
    $order++
}

$layoutsOut = @()
foreach ($layout in @($source.Layouts)) {
    $layoutsOut += [ordered]@{
        nodeId = $nodeMap[[string]$layout.NodeId]
        x = [double]$layout.X
        y = [double]$layout.Y
        width = [double]$layout.Width
        height = [double]$layout.Height
    }
}

$definition = [ordered]@{
    id = $workflowId
    schemaVersion = 3
    name = [string]$source.Name
    description = [string]$source.Description
    isPreset = $true
    nodes = $nodes
    edges = $edges
    layouts = $layoutsOut
    viewport = [ordered]@{
        x = [double]$source.Viewport.X
        y = [double]$source.Viewport.Y
        zoom = [double]$source.Viewport.Zoom
    }
}

$body = $definition | ConvertTo-Json -Depth 60
Save-Json (Join-Path $OutputDirectory 'workflow-definition-request.json') $definition

$draftResponse = Invoke-Utf8JsonPost `
    -Uri "$MesBaseUrl/api/workflows?actor=$([Uri]::EscapeDataString($Actor))" `
    -Body $body
Save-Json (Join-Path $OutputDirectory 'workflow-draft-response.json') ($draftResponse.Content | ConvertFrom-Json)
$draft = $draftResponse.Content | ConvertFrom-Json
$version = [int]$draft.version
if ($version -ne 1) { throw "Expected new workflow version 1, got $version." }

$validationResponse = Invoke-Utf8JsonPost `
    -Uri "$MesBaseUrl/api/workflows/$workflowId/versions/$version/validate"
$validation = $validationResponse.Content | ConvertFrom-Json
Save-Json (Join-Path $OutputDirectory 'workflow-validation-response.json') $validation
if (-not [bool]$validation.isValid) {
    throw ('Workflow validation failed: ' + ($validation.issues | ConvertTo-Json -Depth 20 -Compress))
}

$publishResponse = Invoke-Utf8JsonPost `
    -Uri "$MesBaseUrl/api/workflows/$workflowId/versions/$version/publish?actor=$([Uri]::EscapeDataString($Actor))"
$published = $publishResponse.Content | ConvertFrom-Json
Save-Json (Join-Path $OutputDirectory 'workflow-publish-response.json') $published
$status = [string]$published.status
$publishStatus = [string]$published.publishStatus
if ($status -notin @('Published', '2')) { throw "Unexpected workflow status '$status'." }
if ($publishStatus -notin @('Published', '2')) { throw "Unexpected publish status '$publishStatus'." }

$summary = [ordered]@{
    schema = 'mes.physical-workflow-publication/1.0'
    createdAtUtc = [DateTime]::UtcNow.ToString('O')
    workflowId = $workflowId.ToString()
    version = $version
    name = [string]$source.Name
    nodes = @($nodes).Count
    edges = @($edges).Count
    validationIsValid = [bool]$validation.isValid
    status = $status
    publishStatus = $publishStatus
    actor = $Actor
    writesToDevicesAttempted = $false
}
Save-Json (Join-Path $OutputDirectory 'workflow-publication-evidence.json') $summary
Write-Host "WORKFLOW_ID=$workflowId"
Write-Host "VERSION=$version"
Write-Host "NODES=$(@($nodes).Count) EDGES=$(@($edges).Count)"
Write-Host "VALIDATION=$($validation.isValid) STATUS=$status PUBLISH=$publishStatus"
