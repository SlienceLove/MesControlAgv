[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string]$OutputDirectory,
    [Parameter(Mandatory = $true)] [Guid]$WorkflowId,
    [int]$Version = 1,
    [string]$MesBaseUrl = 'http://127.0.0.1:5145',
    [string]$OperatorName = 'admin',
    [string]$SafetyObserverName = 'admin',
    [string]$PermitPrefix = '一键启动流程-0904',
    [ValidateRange(30, 1440)] [int]$PermitMinutes = 60
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Write-JsonFile {
    param([string]$Path, [object]$Value)
    [IO.File]::WriteAllText(
        $Path,
        ($Value | ConvertTo-Json -Depth 60),
        [Text.UTF8Encoding]::new($false))
}

if (-not (Test-Path -LiteralPath $OutputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}

$requestPath = Join-Path $OutputDirectory 'workflow-execution-request.json'
$markerPath = Join-Path $OutputDirectory 'workflow-execution-attempted.marker'
$responsePath = Join-Path $OutputDirectory 'workflow-execution-response.json'
$errorPath = Join-Path $OutputDirectory 'workflow-execution-error.json'
foreach ($path in @($requestPath, $markerPath, $responsePath, $errorPath)) {
    if (Test-Path -LiteralPath $path) {
        throw "Execution guard refuses to reuse an existing file: $path"
    }
}

$requestId = [Guid]::NewGuid()
$correlationId = 'wpf-physical-batch-' + [Guid]::NewGuid().ToString('N')
$requestedAt = [DateTimeOffset]::UtcNow
$expiresAt = $requestedAt.AddMinutes($PermitMinutes)
$request = [ordered]@{
    workflowId = $WorkflowId.ToString()
    version = $Version
    parameters = [ordered]@{}
    requestedBy = $OperatorName.Trim()
    correlationId = $correlationId
    requestId = $requestId.ToString()
    requestedAt = $requestedAt.ToString('O')
    dryRun = $false
    physicalAuthorization = [ordered]@{
        agvId = 'AGV-01'
        operatorName = $OperatorName.Trim()
        safetyObserverName = $SafetyObserverName.Trim()
        permitPrefix = $PermitPrefix.Trim()
        expiresAtUtc = $expiresAt.ToString('O')
    }
}
Write-JsonFile $requestPath $request

# The marker is created before the POST. A timeout after this point is never
# retried; the request ID is inspected with a GET instead.
$markerText = "requestId=$requestId`ncorrelationId=$correlationId`ncreatedAtUtc=$([DateTime]::UtcNow.ToString('O'))`n"
$markerStream = [IO.File]::Open($markerPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
try {
    $bytes = [Text.Encoding]::UTF8.GetBytes($markerText)
    $markerStream.Write($bytes, 0, $bytes.Length)
}
finally { $markerStream.Dispose() }

$body = $request | ConvertTo-Json -Depth 60
$uri = "$($MesBaseUrl.TrimEnd('/'))/api/workflows/execute"
try {
    $response = Invoke-WebRequest `
        -Uri $uri `
        -Method Post `
        -ContentType 'application/json' `
        -Body $body `
        -UseBasicParsing `
        -TimeoutSec 45
    $responseBody = $response.Content | ConvertFrom-Json
    $envelope = [ordered]@{
        schema = 'mes.physical-workflow-execution-response/1.0'
        observedAtUtc = [DateTime]::UtcNow.ToString('O')
        httpStatus = [int]$response.StatusCode
        requestId = $requestId.ToString()
        correlationId = $correlationId
        response = $responseBody
        postAttemptCount = 1
        writesToDevicesAttemptedByCaller = $false
    }
    Write-JsonFile $responsePath $envelope
    Write-Host "HTTP_STATUS=$($response.StatusCode)"
    Write-Host "REQUEST_ID=$requestId"
    Write-Host "CORRELATION_ID=$correlationId"
    Write-Host "ACCEPTED=$($responseBody.isAccepted)"
    Write-Host "EXECUTION_ID=$($responseBody.executionId)"
    if (-not [bool]$responseBody.isAccepted) {
        throw "MES rejected the one-click request: $($responseBody.rejectionCode) $($responseBody.rejectionReason)"
    }
}
catch {
    $status = $null
    $responseText = $null
    if ($null -ne $_.Exception.Response) {
        try { $status = [int]$_.Exception.Response.StatusCode.value__ } catch { }
        try {
            $reader = [IO.StreamReader]::new($_.Exception.Response.GetResponseStream())
            try { $responseText = $reader.ReadToEnd() } finally { $reader.Dispose() }
        }
        catch { }
    }
    $errorEnvelope = [ordered]@{
        schema = 'mes.physical-workflow-execution-error/1.0'
        observedAtUtc = [DateTime]::UtcNow.ToString('O')
        requestId = $requestId.ToString()
        correlationId = $correlationId
        postAttemptCount = 1
        httpStatus = $status
        responseBody = $responseText
        error = $_.Exception.Message
        note = 'The one-time marker is retained; inspect by request ID and do not resend the POST.'
    }
    Write-JsonFile $errorPath $errorEnvelope
    throw
}
