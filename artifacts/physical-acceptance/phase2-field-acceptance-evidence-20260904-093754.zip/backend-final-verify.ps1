[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [Guid]$ExecutionId,
    [Parameter(Mandatory = $true)] [string]$OutputPath,
    [string]$MesBaseUrl = 'http://127.0.0.1:5145',
    [string]$AdapterBaseUrl = 'http://127.0.0.1:5141'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Get-Json {
    param([Parameter(Mandatory = $true)] [string]$Uri)
    # Emit array members individually so Windows PowerShell does not wrap an
    # endpoint's JSON array in a single Object[] member.
    $value = Invoke-RestMethod -Uri $Uri -Method Get -TimeoutSec 60
    if ($value -is [array]) {
        foreach ($item in $value) { Write-Output $item }
    }
    else {
        Write-Output $value
    }
}

$mes = $MesBaseUrl.TrimEnd('/')
$adapter = $AdapterBaseUrl.TrimEnd('/')
$run = Get-Json "$mes/api/workflow-runs/$ExecutionId"
$nodes = @(Get-Json "$mes/api/workflow-runs/$ExecutionId/nodes")
$operations = @(Get-Json "$mes/api/workflow-runs/$ExecutionId/device-operations")
$acceptances = @(Get-Json "$mes/api/workflow-runs/$ExecutionId/field-navigation-acceptances")
$timeline = @(Get-Json "$mes/api/workflow-runs/$ExecutionId/timeline?limit=500")
$interactions = @(Get-Json "$mes/api/workflow-runs/$ExecutionId/interactions")
$agv = Get-Json "$adapter/agv/snapshot"
$preflight = Get-Json "$adapter/physical/preflight"
$auboStatus = Get-Json "$adapter/api/robot-arms/ARM-01/status"
$auboProgram = Get-Json "$adapter/api/robot-arms/ARM-01/program"
$workflow = Get-Json "$mes/api/workflows/65d9bd5e-73e8-49ae-9510-8541842637fb/versions/1"

$payload = [ordered]@{
    schema = 'mes.physical-workflow-backend-final-verification/1.0'
    verifiedAtUtc = [DateTimeOffset]::UtcNow.ToString('O')
    execution = $run
    nodes = $nodes
    deviceOperations = $operations
    acceptances = $acceptances
    timeline = $timeline
    interactions = $interactions
    finalAgvSnapshot = $agv
    finalAgvPreflight = $preflight
    finalAuboStatus = $auboStatus
    finalAuboProgram = $auboProgram
    workflowVersion = $workflow
}

$parent = Split-Path -Parent ([IO.Path]::GetFullPath($OutputPath))
if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
}
if (Test-Path -LiteralPath $OutputPath) {
    throw "Refusing to overwrite verification file $OutputPath"
}
[IO.File]::WriteAllText(
    $OutputPath,
    ($payload | ConvertTo-Json -Depth 60),
    [Text.UTF8Encoding]::new($false))

Write-Host "EVIDENCE=$OutputPath"
Write-Host "Runtime=$($run.runtimeStatus) Nodes=$($nodes.Count) Ops=$($operations.Count) Acceptances=$($acceptances.Count) Timeline=$($timeline.Count)"
Write-Host "AGV final online=$($agv.online) owner=$($agv.controlOwner) station=$($agv.currentStationId) task=$($agv.currentTaskId)"
Write-Host "AUBO final mode=$($auboStatus.mode) safety=$($auboStatus.safetyMode) op=$($auboStatus.operationalMode) runtime=$($auboStatus.runtimeState) program=$($auboProgram.currentProgram)"
Write-Host '--- node summary ---'
foreach ($node in @($nodes | Sort-Object CreatedAt)) {
    Write-Host ("{0} | {1} | status={2} attempt={3} error={4}" -f $node.nodeName, $node.nodeTypeId, $node.status, $node.attempt, $node.lastError)
}
Write-Host '--- operation summary ---'
foreach ($operation in $operations) {
    Write-Host ("{0} | status={1} | result={2}" -f $operation.capabilityId, $operation.status, ($operation.resultSummary | ConvertTo-Json -Compress))
}
Write-Host '--- acceptance summary ---'
foreach ($acceptance in $acceptances) {
    Write-Host ("{0}->{1} status={2} permit={3}" -f $acceptance.sourceStationId, $acceptance.targetStationId, $acceptance.status, $acceptance.permitId)
}
Write-Host '--- timeline event types ---'
Write-Host (($timeline | ForEach-Object { $_.eventType }) -join ',')
