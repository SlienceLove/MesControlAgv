[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [Guid]$ExecutionId,
    [Parameter(Mandatory = $true)] [string]$OutputDirectory,
    [string]$MesBaseUrl = 'http://127.0.0.1:5145',
    [string]$AdapterBaseUrl = 'http://127.0.0.1:5141',
    [ValidateRange(2, 60)] [int]$PollSeconds = 5,
    [ValidateRange(1, 180)] [int]$MaxMinutes = 60
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if (-not (Test-Path -LiteralPath $OutputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}

$jsonlPath = Join-Path $OutputDirectory 'monitor-snapshots.jsonl'
$finalPath = Join-Path $OutputDirectory 'monitor-final.json'
$statusPath = Join-Path $OutputDirectory 'monitor-status.log'
$terminalStatuses = @(0, 1, 5, 6, 7, 8)
$unsafeNodeStatuses = @(8, 9, 10) # Failed, TimedOut, Unknown

function Get-Json {
    param([Parameter(Mandatory = $true)] [string]$Uri)
    return Invoke-RestMethod -Uri $Uri -Method Get -TimeoutSec 30
}

function Append-Text {
    param([string]$Path, [string]$Text)
    [IO.File]::AppendAllText($Path, $Text + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
}

function Runtime-Name([object]$Value) {
    switch ([int]$Value) {
        0 { 'Rejected'; break }
        1 { 'DryRunCompleted'; break }
        2 { 'Prepared'; break }
        3 { 'Running'; break }
        4 { 'Paused'; break }
        5 { 'Completed'; break }
        6 { 'Failed'; break }
        7 { 'Unknown'; break }
        8 { 'Cancelled'; break }
        default { "Unknown($Value)" }
    }
}

function Node-Name([object]$Value) {
    switch ([int]$Value) {
        0 { 'Pending'; break }
        1 { 'Ready'; break }
        2 { 'WaitingForResource'; break }
        3 { 'Claimed'; break }
        4 { 'Running'; break }
        5 { 'WaitingForSignal'; break }
        6 { 'Succeeded'; break }
        7 { 'Failed'; break }
        8 { 'TimedOut'; break }
        9 { 'Unknown'; break }
        10 { 'Blocked'; break }
        11 { 'Cancelled'; break }
        12 { 'Skipped'; break }
        default { "Unknown($Value)" }
    }
}

$deadline = [DateTime]::UtcNow.AddMinutes($MaxMinutes)
$lastSummary = $null
$lastPreflightAt = [DateTime]::MinValue
$finalReason = 'monitor-timeout'
$lastSnapshot = $null

while ([DateTime]::UtcNow -lt $deadline) {
    $observedAt = [DateTimeOffset]::UtcNow
    try {
        $mesRoot = $MesBaseUrl.TrimEnd('/')
        $adapterRoot = $AdapterBaseUrl.TrimEnd('/')
        $run = Get-Json "$mesRoot/api/workflow-runs/$ExecutionId"
        $nodes = @(Get-Json "$mesRoot/api/workflow-runs/$ExecutionId/nodes")
        $operations = @(Get-Json "$mesRoot/api/workflow-runs/$ExecutionId/device-operations")
        $timeline = @(Get-Json "$mesRoot/api/workflow-runs/$ExecutionId/timeline?limit=500")
        $acceptances = @(Get-Json "$mesRoot/api/workflow-runs/$ExecutionId/field-navigation-acceptances")
        $agv = Get-Json "$adapterRoot/agv/snapshot"
        $auboStatus = Get-Json "$adapterRoot/api/robot-arms/ARM-01/status"
        $auboProgram = Get-Json "$adapterRoot/api/robot-arms/ARM-01/program"

        $preflight = $null
        if (($observedAt.UtcDateTime - $lastPreflightAt).TotalSeconds -ge 30) {
            try {
                $preflight = Get-Json "$adapterRoot/physical/preflight"
                $lastPreflightAt = $observedAt.UtcDateTime
            }
            catch { $preflight = @{ readError = $_.Exception.Message } }
        }

        $nodeRows = @($nodes | Sort-Object CreatedAt | ForEach-Object {
            [ordered]@{
                id = $_.id
                nodeId = $_.nodeId
                type = $_.nodeTypeId
                name = $_.nodeName
                status = [int]$_.status
                statusName = Node-Name $_.status
                attempt = $_.attempt
                lastError = $_.lastError
                outputs = $_.outputs
                startedAt = $_.startedAt
                completedAt = $_.completedAt
            }
        })
        $summary = (($nodeRows | ForEach-Object { "$($_.name)=$($_.statusName)" }) -join ' | ')
        if ($summary -ne $lastSummary) {
            $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fffK') execution=$ExecutionId runtime=$(Runtime-Name $run.runtimeStatus) :: $summary"
            Write-Host $line
            Append-Text $statusPath $line
            $lastSummary = $summary
        }

        $lastSnapshot = [ordered]@{
            schema = 'mes.physical-workflow-monitor-snapshot/1.0'
            observedAtUtc = $observedAt.ToString('O')
            execution = $run
            nodes = $nodes
            deviceOperations = $operations
            acceptances = $acceptances
            timeline = $timeline
            agv = $agv
            auboStatus = $auboStatus
            auboProgram = $auboProgram
            physicalPreflight = $preflight
        }
        Append-Text $jsonlPath (($lastSnapshot | ConvertTo-Json -Depth 40 -Compress))

        $unsafeNode = @($nodes | Where-Object { $unsafeNodeStatuses -contains [int]$_.status })
        if ($unsafeNode.Count -gt 0) {
            $finalReason = 'unsafe-node-state'
            break
        }
        if ([int]$run.runtimeStatus -eq 7) {
            $finalReason = 'workflow-unknown'
            break
        }
        if ([int]$run.runtimeStatus -in @(6, 8)) {
            $finalReason = "workflow-$(Runtime-Name $run.runtimeStatus)"
            break
        }
        if ([int]$run.runtimeStatus -eq 5) {
            $finalReason = 'completed'
            break
        }
    }
    catch {
        $errorLine = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fffK') monitor-read-error: $($_.Exception.Message)"
        Write-Warning $errorLine
        Append-Text $statusPath $errorLine
    }
    Start-Sleep -Seconds $PollSeconds
}

if ($null -ne $lastSnapshot) {
    $lastSnapshot.finalReason = $finalReason
    $lastSnapshot.monitorFinishedAtUtc = [DateTimeOffset]::UtcNow.ToString('O')
    [IO.File]::WriteAllText($finalPath, ($lastSnapshot | ConvertTo-Json -Depth 40), [Text.UTF8Encoding]::new($false))
}
Write-Host "MONITOR_FINAL_REASON=$finalReason"
Write-Host "MONITOR_FINAL=$finalPath"
if ($finalReason -ne 'completed') { exit 2 }
