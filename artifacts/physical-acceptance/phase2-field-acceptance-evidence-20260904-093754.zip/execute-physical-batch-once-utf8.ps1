[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string]$OutputDirectory,
    [Parameter(Mandatory = $true)] [Guid]$WorkflowId,
    [int]$Version = 1,
    [string]$MesBaseUrl = 'http://127.0.0.1:5145',
    [string]$OperatorName = 'admin',
    [string]$SafetyObserverName = 'admin',
    [string]$PermitPrefix = '一键启动流程-0904',
    [ValidateRange(30, 1440)] [int]$PermitMinutes = 60
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Add-Type -AssemblyName System.Net.Http

function Write-JsonFile {
    param([string]$Path, [object]$Value)
    [IO.File]::WriteAllText(
        $Path,
        ($Value | ConvertTo-Json -Depth 60),
        [Text.UTF8Encoding]::new($false))
}

function Invoke-Utf8Post {
    param(
        [Parameter(Mandatory = $true)] [string]$Uri,
        [AllowNull()] [string]$Body
    )
    $client = [System.Net.Http.HttpClient]::new()
    $request = [System.Net.Http.HttpRequestMessage]::new(
        [System.Net.Http.HttpMethod]::Post,
        $Uri)
    try {
        if ($null -ne $Body) {
            $request.Content = [System.Net.Http.StringContent]::new(
                $Body,
                [Text.Encoding]::UTF8,
                'application/json')
        }
        $response = $client.SendAsync($request).GetAwaiter().GetResult()
        $text = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        return [pscustomobject]@{
            StatusCode = [int]$response.StatusCode
            IsSuccess = [bool]$response.IsSuccessStatusCode
            Content = $text
        }
    }
    finally {
        $request.Dispose()
        $client.Dispose()
    }
}

if (-not (Test-Path -LiteralPath $OutputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}
$requestPath = Join-Path $OutputDirectory 'workflow-execution-request.json'
$markerPath = Join-Path $OutputDirectory 'workflow-execution-attempted.marker'
$responsePath = Join-Path $OutputDirectory 'workflow-execution-response.json'
$errorPath = Join-Path $OutputDirectory 'workflow-execution-error.json'
foreach ($path in @($requestPath, $markerPath, $responsePath, $errorPath)) {
    if (Test-Path -LiteralPath $path) {
        throw "Execution guard refuses to reuse an existing file: $path"
    }
}

$requestId = [Guid]::NewGuid()
$correlationId = 'wpf-physical-batch-' + [Guid]::NewGuid().ToString('N')
$requestedAt = [DateTimeOffset]::UtcNow
$expiresAt = $requestedAt.AddMinutes($PermitMinutes)
$request = [ordered]@{
    workflowId = $WorkflowId.ToString()
    version = $Version
    parameters = [ordered]@{}
    requestedBy = $OperatorName.Trim()
    correlationId = $correlationId
    requestId = $requestId.ToString()
    requestedAt = $requestedAt.ToString('O')
    dryRun = $false
    physicalAuthorization = [ordered]@{
        agvId = 'AGV-01'
        operatorName = $OperatorName.Trim()
        safetyObserverName = $SafetyObserverName.Trim()
        permitPrefix = $PermitPrefix.Trim()
        expiresAtUtc = $expiresAt.ToString('O')
    }
}
$body = $request | ConvertTo-Json -Depth 60
Write-JsonFile $requestPath $request

$markerText = "requestId=$requestId`ncorrelationId=$correlationId`ncreatedAtUtc=$([DateTime]::UtcNow.ToString('O'))`n"
$markerStream = [IO.File]::Open(
    $markerPath,
    [IO.FileMode]::CreateNew,
    [IO.FileAccess]::Write,
    [IO.FileShare]::Read)
try {
    $bytes = [Text.Encoding]::UTF8.GetBytes($markerText)
    $markerStream.Write($bytes, 0, $bytes.Length)
}
finally { $markerStream.Dispose() }

$uri = "$($MesBaseUrl.TrimEnd('/'))/api/workflows/execute"
$result = Invoke-Utf8Post -Uri $uri -Body $body
if (-not $result.IsSuccess) {
    $errorEnvelope = [ordered]@{
        schema = 'mes.physical-workflow-execution-error/1.0'
        observedAtUtc = [DateTime]::UtcNow.ToString('O')
        requestId = $requestId.ToString()
        correlationId = $correlationId
        postAttemptCount = 1
        httpStatus = $result.StatusCode
        responseBody = $result.Content
        error = "HTTP $($result.StatusCode)"
        note = 'The one-time marker is retained; inspect by request ID and do not resend the POST.'
    }
    Write-JsonFile $errorPath $errorEnvelope
    throw "MES execution request failed with HTTP $($result.StatusCode)."
}

$responseBody = $result.Content | ConvertFrom-Json
$envelope = [ordered]@{
    schema = 'mes.physical-workflow-execution-response/1.0'
    observedAtUtc = [DateTime]::UtcNow.ToString('O')
    httpStatus = $result.StatusCode
    requestId = $requestId.ToString()
    correlationId = $correlationId
    response = $responseBody
    postAttemptCount = 1
    writesToDevicesAttemptedByCaller = $false
}
Write-JsonFile $responsePath $envelope
Write-Host "HTTP_STATUS=$($result.StatusCode)"
Write-Host "REQUEST_ID=$requestId"
Write-Host "CORRELATION_ID=$correlationId"
Write-Host "ACCEPTED=$($responseBody.isAccepted)"
Write-Host "EXECUTION_ID=$($responseBody.executionId)"
if (-not [bool]$responseBody.isAccepted) {
    throw "MES rejected the one-click request: $($responseBody.rejectionCode) $($responseBody.rejectionReason)"
}
