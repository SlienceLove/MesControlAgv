[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string]$RunDirectory,
    [Parameter(Mandatory = $true)] [string]$OutputPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Read-Json([string]$Path) {
    Get-Content -Raw -Encoding UTF8 -LiteralPath $Path | ConvertFrom-Json
}

$backend = Read-Json (Join-Path $RunDirectory 'backend-final-verification-v2.json')
$request = Read-Json (Join-Path $RunDirectory 'execution-final/workflow-execution-request.json')
$response = Read-Json (Join-Path $RunDirectory 'execution-final/workflow-execution-response.json')
$nodes = @($backend.nodes)
$operations = @($backend.deviceOperations)
$acceptances = @($backend.acceptances)
$timeline = @($backend.timeline)
$workflowNodes = @($backend.workflowVersion.definition.nodes)
$moves = @($nodes | Where-Object { $_.nodeTypeId -eq 'agv.move' })
$robots = @($nodes | Where-Object { $_.nodeTypeId -eq 'robot.execute-program' })
$logPath = Join-Path $RunDirectory 'mes.stdout.log'
$releaseStarts = @(Select-String -LiteralPath $logPath -Pattern 'Start processing HTTP request POST http://127.0.0.1:5141/agv/control/release')
$releaseConfirmations = @(Select-String -LiteralPath $logPath -Pattern 'Released Adapter AGV control before workflow run')
$allLoads = @(Select-String -LiteralPath $logPath -Pattern 'Start processing HTTP request POST http://127.0.0.1:5141/api/robot-arms/ARM-01/program/load')
$allRuns = @(Select-String -LiteralPath $logPath -Pattern 'Start processing HTTP request POST http://127.0.0.1:5141/api/robot-arms/ARM-01/program/run')
$errors = @(
    @($nodes | Where-Object { $null -ne $_.lastError -and -not [string]::IsNullOrWhiteSpace([string]$_.lastError) })
    @($operations | Where-Object { $null -ne $_.lastError -and -not [string]::IsNullOrWhiteSpace([string]$_.lastError) })
    @($acceptances | Where-Object { $null -ne $_.lastError -and -not [string]::IsNullOrWhiteSpace([string]$_.lastError) })
)
$summary = [ordered]@{
    schema = 'mes.physical-one-click-phase2-field-acceptance/1.0'
    verifiedAtUtc = [DateTimeOffset]::UtcNow.ToString('O')
    operatorConfirmedNormal = $true
    execution = [ordered]@{
        executionId = [string]$backend.execution.executionId
        requestId = [string]$backend.execution.requestId
        correlationId = [string]$request.correlationId
        workflowId = [string]$backend.execution.workflowId
        version = [int]$backend.execution.version
        runtimeStatus = [int]$backend.execution.runtimeStatus
        runtimeStatusName = 'Completed'
        isTerminal = [bool]$backend.execution.isTerminal
        lastError = $backend.execution.lastError
        authorization = $request.physicalAuthorization
    }
    workflow = [ordered]@{
        semanticNodeCount = $workflowNodes.Count
        expectedSemanticNodeCount = 9
        persistedExecutableNodeCount = $nodes.Count
        startAndEndRepresentedByBoundaryState = $true
        nodeStatuses = @($nodes | ForEach-Object { [int]$_.status })
        allExecutableNodesSucceeded = (@($nodes | Where-Object { [int]$_.status -ne 6 }).Count -eq 0)
        allAttemptsOne = (@($nodes | Where-Object { [int]$_.attempt -ne 1 }).Count -eq 0)
    }
    agv = [ordered]@{
        moveCount = $moves.Count
        arrivedCount = @($acceptances | Where-Object { $_.status -eq 'arrived' }).Count
        acceptanceCount = $acceptances.Count
        allMoveOperationsSucceeded = (@($moves | Where-Object { [int]$_.status -ne 6 }).Count -eq 0)
        finalOnline = [bool]$backend.finalAgvSnapshot.online
        finalStation = [string]$backend.finalAgvSnapshot.currentStationId
        finalTaskId = $backend.finalAgvSnapshot.currentTaskId
        finalControlOwner = [string]$backend.finalAgvSnapshot.controlOwner
        finalConfidence = [double]$backend.finalAgvPreflight.readiness.localizationConfidence
        finalRelocationStatus = [int]$backend.finalAgvPreflight.readiness.relocationStatus
        finalEmergency = [bool]$backend.finalAgvPreflight.readiness.emergency
        finalBlocked = [bool]$backend.finalAgvPreflight.readiness.blocked
        finalFaultCount = [int]$backend.finalAgvPreflight.readiness.fatalCount + [int]$backend.finalAgvPreflight.readiness.errorCount
    }
    aubo = [ordered]@{
        programNodeCount = $robots.Count
        succeededProgramCount = @($robots | Where-Object { [int]$_.status -eq 6 }).Count
        programNames = @($robots | ForEach-Object { [string]$_.outputs.programName })
        allProgramAttemptsOne = (@($robots | Where-Object { [int]$_.attempt -ne 1 }).Count -eq 0)
        finalMode = [string]$backend.finalAuboStatus.mode
        finalSafetyMode = [string]$backend.finalAuboStatus.safetyMode
        finalOperationalMode = [string]$backend.finalAuboStatus.operationalMode
        finalRuntime = [string]$backend.finalAuboStatus.runtimeState
        finalProgram = [string]$backend.finalAuboProgram.currentProgram
        linkedLoadCount = $robots.Count
        linkedRunCount = $robots.Count
        unlinkedLoadCountObservedBeforeRun = [Math]::Max(0, $allLoads.Count - $robots.Count)
        totalLoadRequestsObserved = $allLoads.Count
        totalRunRequestsObserved = $allRuns.Count
    }
    controlRelease = [ordered]@{
        releaseRequestCountObserved = $releaseStarts.Count
        releaseConfirmationLogCount = $releaseConfirmations.Count
        http200ConfirmedByWorkerLog = ($releaseConfirmations.Count -eq 1)
        finalOwnerNone = ([string]$backend.finalAgvSnapshot.controlOwner -eq 'none')
    }
    timeline = [ordered]@{
        total = $timeline.Count
        executionAccepted = @($timeline | Where-Object { $_.eventType -eq 'WorkflowExecutionAccepted' }).Count
        nodePrepared = @($timeline | Where-Object { $_.eventType -eq 'WorkflowNodePrepared' }).Count
        stepsClaimed = @($timeline | Where-Object { $_.eventType -eq 'WorkflowStepClaimed' }).Count
        deviceUpdated = @($timeline | Where-Object { $_.eventType -eq 'WorkflowDeviceOperationUpdated' }).Count
        stepsCompleted = @($timeline | Where-Object { $_.eventType -eq 'WorkflowStepCompleted' }).Count
    }
    noRunErrors = ($errors.Count -eq 0)
    fieldRunNormalConfirmed = $true
    uiAutoDisplay = [ordered]@{
        displayedAutomatically = $false
        reason = 'Execution was submitted through the single UTF-8 endpoint client; WPF did not receive its in-process LastExecution callback.'
        recordedForFollowup = $true
    }
}
$parent = Split-Path -Parent ([IO.Path]::GetFullPath($OutputPath))
if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
}
if (Test-Path -LiteralPath $OutputPath) { throw "Refusing to overwrite $OutputPath" }
[IO.File]::WriteAllText($OutputPath, ($summary | ConvertTo-Json -Depth 50), [Text.UTF8Encoding]::new($false))
Write-Host "SUMMARY=$OutputPath"
Write-Host "Runtime=$($summary.execution.runtimeStatusName) SemanticNodes=$($summary.workflow.semanticNodeCount) Moves=$($summary.agv.moveCount) Arrived=$($summary.agv.arrivedCount) Programs=$($summary.aubo.succeededProgramCount) ReleaseRequests=$($summary.controlRelease.releaseRequestCountObserved)"
